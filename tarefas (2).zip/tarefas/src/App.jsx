import ListaDeTarefas from "./componentes/ListaDeTarefas"


function App() {
  return (
    
    <ListaDeTarefas/>
    
  )
}

export default App
